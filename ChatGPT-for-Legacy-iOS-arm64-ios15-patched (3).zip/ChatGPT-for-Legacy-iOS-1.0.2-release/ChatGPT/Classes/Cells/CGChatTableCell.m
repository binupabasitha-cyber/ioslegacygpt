//
//  CGChatTableCell.m
//  ChatGPT
//
//  Created by XML on 18/01/25.
//  Copyright (c) 2025 XML. All rights reserved.
//

#import "CGChatTableCell.h"
#import "CGAPIHelper.h"

@implementation CGChatTableCell

- (void)configureWithMessage:(NSString *)messageText {
    TSMarkdownParser *parser = [TSMarkdownParser standardParser];

    NSAttributedString *attributedText = [parser attributedStringFromMarkdown:messageText];
    if (attributedText) {
    } else {
    }
    
    // Dark mode: give the message text theme-aware colors (links / code colors are kept)
    NSMutableAttributedString *themed = [[NSMutableAttributedString alloc] initWithAttributedString:attributedText ?: [[NSAttributedString alloc] initWithString:@""]];
    UIColor *baseText = self.contentTextView.textColor ?: [UIColor blackColor];
    UIColor *defaultText = [CGAPIHelper themedTextColorFor:baseText] ?: baseText;
    [themed enumerateAttribute:NSForegroundColorAttributeName inRange:NSMakeRange(0, themed.length) options:0 usingBlock:^(id value, NSRange range, BOOL *stop) {
        if (value == nil) {
            [themed addAttribute:NSForegroundColorAttributeName value:defaultText range:range];
        } else {
            UIColor *mapped = [CGAPIHelper themedTextColorFor:value];
            if (mapped) [themed addAttribute:NSForegroundColorAttributeName value:mapped range:range];
        }
    }];
    self.contentTextView.tag = 7001;
    self.contentTextView.attributedText = themed;
    [self adjustTextViewSize];
}


- (void)adjustTextViewSize {
    CGSize maxSize = CGSizeMake(self.contentTextView.frame.size.width, CGFLOAT_MAX);
    CGSize newSize = [self.contentTextView sizeThatFits:maxSize];
    
    CGRect newFrame = self.contentTextView.frame;
    newFrame.size.height = newSize.height;
    self.contentTextView.frame = newFrame;
}

@end
